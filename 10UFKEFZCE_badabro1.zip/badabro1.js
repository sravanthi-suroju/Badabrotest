let RatingForBrand = {
    "Samsung": 5,
    "Nokia": 3,
    "Redmi": 3,
    "Oppo": 2,
    "Vivo": 1,
    "OnePlus": 4,
    "Others": 1
};
let NumberOfContact = {
    "300+": 5,
    "200-300": 4,
    "150-200": 3,
    "100-150": 2,
    "0-100": 1
};
let PhotoClarity = {
    "80-100": 5,
    "60-80": 4,
    "40-60": 3,
    "20-40": 2,
    "0-20": 1
};
let NumberOfSubmission = {
    "1": 5,
    "2": 4,
    "3": 3,
    "4": 2,
    "4+": 1
};
let CompanyOrCollege = {
    "Tyre 1": 5,
    "Tyre 2": 3,
    "Tyre 3": 2,
    "Unknown": 1
};

let formData = {
    brand: "Samsung",
    contact: "300+",
    photo: "80-100",
    submission: "1",
    company: "Tyre 1"
};

let addUserForm = document.getElementById("addUserForm");
let brand = document.getElementById("brand");
let contact = document.getElementById("contact");
let photo = document.getElementById("photo");
let submission = document.getElementById("submission");
let company = document.getElementById("company");
let button = document.getElementById("button");
let result = document.getElementById("result");


brand.addEventListener("change", function(event) {
    formData.brand = event.target.value;
});

contact.addEventListener("change", function(event) {
    formData.contact = event.target.value;
});

photo.addEventListener("change", function(event) {
    formData.photo = event.target.value;
});

submission.addEventListener("change", function(event) {
    formData.submission = event.target.value;
});

company.addEventListener("change", function(event) {
    formData.company = event.target.value;
});

function searchingValues(formData) {
    let valuesArray = [];
    const {
        brand,
        contact,
        photo,
        submission,
        company
    } = formData;
    if (brand in RatingForBrand) {
        valuesArray.push(RatingForBrand[brand]);
    }
    if (contact in NumberOfContact) {
        valuesArray.push(NumberOfContact[contact]);
    }
    if (photo in PhotoClarity) {
        valuesArray.push(PhotoClarity[photo]);
    }
    if (submission in NumberOfSubmission) {
        valuesArray.push(NumberOfSubmission[submission]);
    }
    if (company in CompanyOrCollege) {
        valuesArray.push(CompanyOrCollege[company]);
    }
    return valuesArray;
}
addUserForm.addEventListener("submit", function(event) {
    event.preventDefault();
    let valuesArray = searchingValues(formData);
    let valuesLength = valuesArray.length;
    let sum = valuesArray.reduce((acc, cum) => acc + cum);
    let avg = sum / valuesLength;
    result.textContent = "Average is: " + avg;
});